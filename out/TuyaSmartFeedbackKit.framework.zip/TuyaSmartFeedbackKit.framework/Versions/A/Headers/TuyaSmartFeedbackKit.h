//
//  TuyaSmartFeedbackKit.h
//  TuyaSmartFeedbackKit
//
//  Created by 高森 on 2019/1/18.
//

#ifndef TuyaSmartFeedbackKit_h
#define TuyaSmartFeedbackKit_h

#import "TuyaSmartFeedback.h"

#endif /* TuyaSmartFeedbackKit_h */
