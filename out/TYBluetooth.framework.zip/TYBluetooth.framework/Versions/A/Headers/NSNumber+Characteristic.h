//
//  NSNumber+Characteristic.h
//  TuyaSmartPublic
//
//  Created by 冯晓 on 16/8/2.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (Characteristic)

- (NSString *)tp_CoreBLE_Characteristic2String;

@end
