//
//  TuyaSmartMessageKit.h
//  TuyaSmartMessageKit
//
//  Created by 高森 on 2019/1/18.
//

#ifndef TuyaSmartMessageKit_h
#define TuyaSmartMessageKit_h

#import "TuyaSmartMessage.h"

#endif /* TuyaSmartMessageKit_h */
