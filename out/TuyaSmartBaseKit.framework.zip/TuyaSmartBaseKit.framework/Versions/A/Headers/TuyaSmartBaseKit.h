//
//  TuyaSmartKit.h
//  TuyaSmartKit
//
//  Created by fengyu on 15/9/11.
//  Copyright (c) 2015年 Tuya. All rights reserved.
//


/**
 *  当前SDK为全屋智能SDK
 */
#define TUYA_HOMEKIT_SDK

/**
 *  当前SDK的版本号
 */
#define TUYA_SDK_VERSION @"2.7.20"

#import "TuyaSmartSDK.h"
#import "TuyaSmartUser.h"
#import "TuyaSmartRequest.h"

