//
//  TuyaSmartBLEDevice.h
//  TuyaSmartBLEKit
//
//  Created by 黄凯 on 2018/9/27.
//

#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>

@interface TuyaSmartBLEDevice : TuyaSmartDevice

@end
