//
//  UIDevice+TYUUID.h
//  TuyaSmartBaseKit
//
//  Created by 高森 on 2018/6/11.
//

#import <UIKit/UIKit.h>

@interface UIDevice (TYUUID)

+ (NSString *)ty_UUID;

+ (NSString *)ty_deviceNameString;

@end
