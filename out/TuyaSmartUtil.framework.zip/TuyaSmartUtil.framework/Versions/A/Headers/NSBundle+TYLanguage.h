//
//  NSBundle+TYLanguage.h
//  TuyaSmartBaseKit
//
//  Created by lan on 2018/9/4.
//  Copyright © 2018年 Tuya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSBundle (TYLanguage)

+ (NSString *)ty_getAppleLanguages;

@end
