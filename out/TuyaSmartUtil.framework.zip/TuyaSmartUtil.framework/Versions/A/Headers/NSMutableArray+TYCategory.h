//
//  NSMutableArray+TYCategory.h
//  TYLibraryExample
//
//  Created by 冯晓 on 16/2/16.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (TYCategory)

- (void)ty_safeAddObject:(id)anObject;

@end
