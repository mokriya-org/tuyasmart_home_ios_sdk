//
//  TuyaSmartSIGMeshDevice.h
//  TuyaSmartBLEMeshKit
//
//  Created by 黄凯 on 2019/3/13.
//

#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TuyaSmartSIGMeshDevice : TuyaSmartDevice

@end

NS_ASSUME_NONNULL_END
