//
//  TuyaSmartSceneExprModel.h
//  TuyaSmartSceneKit
//
//  Created by TuyaInc on 2019/4/19.
//

#import <Foundation/Foundation.h>


@interface TuyaSmartSceneExprModel : NSObject

@property (nonatomic, strong) NSArray *expr;

@end

